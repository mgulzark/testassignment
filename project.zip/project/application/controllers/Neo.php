<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Neo extends CI_Controller {
	
	public function __construct() 
	{
		parent::__construct();
		$this->load->dbforge();
		$this->load->model('Neos_model');
	}
	
	public function index()
	{
		$this->Neos_model->create_nasa_table();
		
		$start_date = date('Y-m-d',strtotime('-2 days'));
		$end_date = date('Y-m-d',strtotime('today'));
		$http_url = 'https://api.nasa.gov/neo/rest/v1/feed?start_date='.$start_date.'&end_date='.$end_date.'&detailed=false&api_key=N7LkblDsc5aen05FJqBQ8wU4qSdmsftwJagVK7UD';
		
		$asteroids = file_get_contents($http_url);
		$asteroids_array = json_decode($asteroids);

		
		$asteriods_objects = $asteroids_array->near_earth_objects;
		
		foreach($asteriods_objects as $asteriod) {
			foreach($asteriod as $single_asteriod) {
				$neo_date = $single_asteriod->close_approach_data[0]->close_approach_date;
				$reference_id = $single_asteriod->neo_reference_id;
				$reference_name = $single_asteriod->name;
				$speed = $single_asteriod->close_approach_data[0]->relative_velocity->kilometers_per_hour;
				if($single_asteriod->is_potentially_hazardous_asteroid) { $hazardous = 1; } else { $hazardous = 0; }
				
				$this->Neos_model->add_neo_records($neo_date,$reference_id,$reference_name,$speed,$hazardous);
			}
		}
		$data['message'] = "All the NEO's Records are added in database successfully";
		$data['near_earth_objects'] = $asteroids_array->element_count;
		$this->load->view('nasa_neos',$data);
	}
	
	public function hazardous_asteroids()
	{
		$neo_records = $this->Neos_model->hazardous_asteroids_records();
		$data['hazardous_asteroid'] = json_encode($neo_records);
		$this->load->view('hazardous_asteroids_list',$data);
	}
	
	public function fastest_asteroids($hazardous = false)
	{
		$hazardous = $this->input->get('hazardous', TRUE);
		if($hazardous== 'true') {$hazardous_val = 1; } else { $hazardous_val = 0; }
		$neo_records = $this->Neos_model->fastest_asteroids_records($hazardous_val);
		$data['fastest_asteroids'] = json_encode($neo_records);
		$this->load->view('fastest_asteroids',$data);
	}
	
	public function best_year($hazardous = false)
	{
		$hazardous = $this->input->get('hazardous', TRUE);
		if($hazardous== 'true') {$hazardous_val = 1; } else { $hazardous_val = 0; }
		$neo_records = $this->Neos_model->best_year_records($hazardous_val);
		$data['best_year'] = json_encode($neo_records);
		$this->load->view('best_year',$data);
	}
	
}
