<?php class Neos_model extends CI_Model {
	
	public function __construct()
	{
		$this->load->database();
		$this->load->dbforge();
	}
	
	public function create_nasa_table()
	{
		$fields = array(
			'record_id' => array(
				'type' => 'INT',
				'constraint' => 10,
    			'unsigned' => TRUE,
    			'auto_increment' => TRUE,
				'null' => FALSE,
			),
			'date' => array(
				'type' => 'VARCHAR',
    			'constraint' => 20
			),
			'reference' => array(
				'type' => 'VARCHAR',
    			'constraint' => 30
			),
			'name' => array(
				'type' => 'VARCHAR',
    			'constraint' => 30
			),
			'speed' => array(
				'type' => 'VARCHAR',
    			'constraint' => 30
			),
			'is_hazardous' => array(
				'type' => 'INT',
    			'constraint' => 2,
				'null' => FALSE
			)
		);
		
		$this->dbforge->add_field($fields);
		
		// define primary key
		$this->dbforge->add_key('record_id', TRUE);
		
		// create table if not Exists
		$this->dbforge->create_table('neo_records', TRUE);
		
		// Empty the table so if we refresh page several time it may not add duplicate enteries
		$this->db->empty_table('neo_records');
	}
	
	public function add_neo_records($neo_date,$reference_id,$reference_name,$speed,$hazardous)
	{
		$neo_data = array(
			'record_id' => '',
			'date' => $neo_date,
			'reference' => $reference_id,
			'name' => $reference_name,
			'speed' => $speed,
			'is_hazardous' => $hazardous,
		);
		$prefixed_tablename = $this->db->dbprefix('neo_records');
		$query_status = $this->db->insert($prefixed_tablename, $neo_data); 
		return $query_status;
	}
	public function hazardous_asteroids_records()
	{
		$condition = array('is_hazardous' => 1);
		$this->db->select('*');
		$prefixed_tablename = $this->db->dbprefix('neo_records');
		$this->db->from($prefixed_tablename);
		$this->db->where($condition);
		$query = $this->db->get();
		return $query->result();
	}
	
	public function fastest_asteroids_records($hazardous_val)
	{
		$condition = array('is_hazardous' => $hazardous_val);
		$this->db->select_max('speed');
		$prefixed_tablename = $this->db->dbprefix('neo_records');
		$this->db->from($prefixed_tablename);
		$this->db->where($condition);
		$query = $this->db->get()->result();
		$higgest_speed = $query[0]->speed;
		
		
		$condition = array('speed' => $higgest_speed);
		$this->db->select('*');
		$prefixed_tablename = $this->db->dbprefix('neo_records');
		$this->db->from($prefixed_tablename);
		$this->db->where($condition);
		$query = $this->db->get();
		//print_r($query->result());
		return $query->result();
	}
	
	public function best_year_records($hazardous_val)
	{
		$condition = array('is_hazardous' => $hazardous_val);
		$this->db->select('date, COUNT(date) as total');
		//$this->db->from($prefixed_tablename);
		$this->db->where($condition);
		
 		$this->db->group_by('date'); 
 		$this->db->order_by('total', 'desc'); 
 		$query = $this->db->get('neo_records', 1);
		return $query->result();
	}
}